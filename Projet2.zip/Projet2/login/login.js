function login(event) {
  console.log("TEST")
  event.preventDefault();
  let dataForm = new URLSearchParams(new FormData(event.target));

  fetch("http://localhost:2000/login", {
      method: "POST",
      body: dataForm
  })
  .then( reponse => {
      return reponse.json()
  })
  .then(reponseJson => {

      if(reponseJson.success) {
          window.location.href = "http://localhost:5000/admin/";
          console.log(reponseJson.nom_utilisateur)
      }
      else {
          alert("Mauvaises informations")
      }
  })
}
(function() {
  window.onload = function() {
    setTimeout(function() {
      alert("Votre compte est désormais bloqué");
      attempts = 0;
    }, 6000);
  };

    // counter counting number of attempts
  var attempts = 2;

  // messages to display in case of success / errors
  var messages = {
    "exceededAttempts": "You have exceeded the number of attempts to Log in.\nPlease try again later.",
    "missingUsername": "Please check the username field and try again",
    "missingPassword": "Please check the password field and try again",
    "missingFields": "Please check the form and try again",
    'success': "Login Success",
    'fail': "Login Failed"
  };

  // form elements

  var form = document.getElementById("login-form");
  var usernameField = document.getElementsByName("username")[0];
  var passwordField = document.getElementsByName("password")[0];
  var submitButton = document.getElementsByClassName("button-submit")[0];

    // valid credentials

  var validCredentials = {
    "username": "admin",
    "password": "admin"
  };

    /**
  * @function login
  * authenticates the user
  */
  function login() {
    // check if user is within allowed attemption limit
    if (attempts > 0) {
        // username and password value
      var username = usernameField.value;
      var password = passwordField.value;

            // if username or password is blank
      if (username === "" || password === "") {
        // if username and password ARE blank
        if (username === "" && password === "") {
          alert(messages.missingFields);
        } else {
            // if only username is blank
          if (username === "") {
            alert(messages.missingUsername);
          } else if (password === "") {
            // if only password is blank
            alert(messages.missingPassword);
          }
        }
      } else {
        // the form is filled and username and password are as     expected
        if (username === validCredentials.username && password === validCredentials.password) {
          alert(messages.success);
        } else {
            // the username and password are not as expected
          alert(messages.fail);
        }
      }
      // count down number of attempts
      attempts--;
    } else {
        // notify user that he/she is out of attempts
      alert(messages.exceededAttempts);
    }
  };

  // when form is submitted
  form.onsubmit = function(e) {
    // stop default behaviour
    e.preventDefault();
    login();
  }

  // when submit button is clicked
  submitButton.onclick = function(e) {
    // stop default behaviour
    e.preventDefault();
    login();
  }

})();